import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.scans.create.path, async (req, res) => {
    try {
      const { image } = req.body;
      if (!image) {
        return res.status(400).json({ message: "Image is required" });
      }

      const response = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages: [
          {
            role: "system",
            content: `You are an expert medical document OCR assistant specialized in reading Arabic medical documents, prescriptions, and lab reports — including difficult doctor handwriting.

CRITICAL RULES:
1. Extract ONLY text you can actually read. NEVER guess or fabricate text.
2. If a word or section is truly illegible, write [غير واضح] — do NOT invent text.
3. For partially readable text, show what you can read and mark unclear parts: "كلمة [غير واضح] كلمة"
4. Preserve the original language (Arabic, English, or mixed).

RESPOND IN THIS EXACT STRUCTURED FORMAT using these section headers:

## بيانات المريض
(Patient name, age, ID, date — only if visible)

## التشخيص
(Each diagnosis on its own line with ICD-10 code)
Format: "اسم التشخيص (ICD-10: XXX) — نبذة مختصرة جداً في سطر واحد"

## التحاليل المطلوبة
(Each test on its own line with a very brief Arabic description of what the test measures)
Format: "اسم التحليل — وصف مختصر"
Example: "CBC — صورة دم كاملة لتقييم خلايا الدم الحمراء والبيضاء والصفائح"
Example: "HbA1c — معدل السكر التراكمي خلال 3 أشهر"
Example: "SGOT/SGPT — إنزيمات الكبد لتقييم وظائف الكبد"

## الأدوية
(Each medication on its own line with dosage if visible)

## ملاحظات
(Any other relevant text from the document)

IMPORTANT:
- Keep descriptions very brief (one short line per item).
- If a section has no data, skip it entirely.
- Focus on accuracy. [غير واضح] is better than guessing.
- Cover ALL types of lab tests: blood, urine, hormones, imaging, cultures, etc.
- Always add ICD-10 codes for every diagnosis found.`
          },
          {
            role: "user",
            content: [
              { type: "text", text: "اقرأ هذا المستند الطبي بدقة عالية. استخرج كل النص المقروء فقط، ولا تخمن أي كلمة غير واضحة. أضف أكواد ICD-10 لأي تشخيص طبي تجده." },
              {
                type: "image_url",
                image_url: {
                  url: image,
                },
              },
            ],
          },
        ],
        max_completion_tokens: 4096,
      });

      const extractedText = response.choices[0].message.content || "Could not extract text.";

      const scan = await storage.createScan({
        imageUrl: image.substring(0, 200),
        extractedText: extractedText,
      });

      res.json({ ...scan, imageUrl: image });
    } catch (error: any) {
      console.error("Scan error:", error?.message || error);
      res.status(500).json({ message: "Failed to process image. Please try again." });
    }
  });

  app.get(api.scans.list.path, async (req, res) => {
    const scans = await storage.getScans();
    res.json(scans);
  });

  app.get(api.scans.get.path, async (req, res) => {
    const scan = await storage.getScan(req.params.id);
    if (!scan) {
      return res.status(404).json({ message: "Scan not found" });
    }
    res.json(scan);
  });

  app.delete("/api/scans/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteScan(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Scan not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      console.error("Delete error:", error?.message || error);
      res.status(500).json({ message: "Failed to delete scan" });
    }
  });

  app.post("/api/feedback", async (req, res) => {
    try {
      const { name, email, message } = req.body;
      if (!message || !message.trim()) {
        return res.status(400).json({ message: "Message is required" });
      }
      const feedback = await storage.createFeedback({
        name: name || null,
        email: email || null,
        message: message.trim(),
      });

      // Send email via SendGrid integration
      try {
        const { getUncachableSendGridClient } = await import("./sendgrid");
        const { client, fromEmail } = await getUncachableSendGridClient();
        await client.send({
          to: "komanda.hamada@gmail.com",
          from: { email: fromEmail, name: "MedScan App" },
          replyTo: email || fromEmail,
          subject: `${name || "مستخدم"}: ${message.trim().substring(0, 50)}`,
          text: `الاسم: ${name || "غير محدد"}\nالبريد: ${email || "غير محدد"}\n\nالرسالة:\n${message.trim()}`,
          html: `<div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;background:#ffffff;color:#333333;">
            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;"><tr>
              <td style="font-size:18px;font-weight:bold;color:#333333;">MedScan - رسالة جديدة</td>
            </tr></table>
            <table width="100%" cellpadding="8" cellspacing="0" style="background:#f9f9f9;border:1px solid #eeeeee;margin-bottom:16px;">
              <tr><td style="color:#666666;">الاسم</td><td style="color:#333333;">${name || "غير محدد"}</td></tr>
              <tr><td style="color:#666666;">البريد</td><td style="color:#333333;">${email || "غير محدد"}</td></tr>
            </table>
            <div style="padding:12px;background:#f9f9f9;border:1px solid #eeeeee;white-space:pre-wrap;color:#333333;line-height:1.6;">${message.trim()}</div>
          </div>`,
        });
      } catch (emailErr: any) {
        console.error("SendGrid email error:", emailErr?.message || emailErr);
      }

      res.json({ success: true, id: feedback.id });
    } catch (error: any) {
      console.error("Feedback error:", error?.message || error);
      res.status(500).json({ message: "Failed to save feedback" });
    }
  });

  return httpServer;
}
