// SendGrid integration - uses SENDGRID_API_KEY secret with Replit Connectors as fallback
import sgMail from '@sendgrid/mail';

async function getCredentialsFromConnector() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? 'repl ' + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
    ? 'depl ' + process.env.WEB_REPL_RENEWAL
    : null;

  if (!xReplitToken || !hostname) {
    return null;
  }

  try {
    const connectionSettings = await fetch(
      'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=sendgrid',
      {
        headers: {
          'Accept': 'application/json',
          'X_REPLIT_TOKEN': xReplitToken
        }
      }
    ).then(res => res.json()).then(data => data.items?.[0]);

    if (connectionSettings?.settings?.api_key?.startsWith('SG.') && connectionSettings?.settings?.from_email) {
      return { apiKey: connectionSettings.settings.api_key, email: connectionSettings.settings.from_email };
    }
  } catch {}
  return null;
}

export async function getUncachableSendGridClient() {
  const connectorCreds = await getCredentialsFromConnector();

  if (connectorCreds) {
    sgMail.setApiKey(connectorCreds.apiKey);
    return { client: sgMail, fromEmail: connectorCreds.email };
  }

  const apiKey = process.env.SENDGRID_API_KEY;
  if (!apiKey || !apiKey.startsWith('SG.')) {
    throw new Error('SendGrid API key not configured');
  }

  sgMail.setApiKey(apiKey);
  return { client: sgMail, fromEmail: 'komanda.hamada@gmail.com' };
}
