--
-- PostgreSQL database dump
--

\restrict MfOG9QUQG0ZcdMgSIRnd2HyV5hidUhHINEwaCTt2fnZb5aupE6DlB3eEoQN1szd

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: feedbacks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feedbacks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    email text,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.feedbacks OWNER TO postgres;

--
-- Name: scans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    image_url text NOT NULL,
    extracted_text text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.scans OWNER TO postgres;

--
-- Data for Name: feedbacks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feedbacks (id, name, email, message, created_at) FROM stdin;
ba00d7d4-ca93-4f01-9fa0-40efe28bb379	تجربة	test@example.com	تطبيق رائع جداً، اقتراح: إضافة دعم PDF	2026-02-09 03:24:04.432313
fe9c019c-f894-4fff-bf61-fc10ac47d9fa	Ahmed	komanda.hamada@gmail.com	Good app 👍	2026-02-09 03:24:55.643449
4a6c4d7c-60ad-4f8d-be4f-0fee7ea5b08f	Komandoz	komanda.hamada@gmail.com	Wonderful application	2026-02-09 03:30:03.429709
b380d0c8-3e0d-4a35-9a59-07b604c07dd6	Koko	komanda.hamada@gmail.com	Best app	2026-02-09 03:49:44.38023
dedb1cca-d686-4105-973a-db5e0fbd562e	تجربة إرسال	test@test.com	تجربة إرسال إيميل من MedScan	2026-02-09 03:51:03.091686
1a236045-9110-4515-a7c4-7e02130daecc	تجربة إرسال	test@test.com	تجربة إرسال إيميل من تطبيق MedScan - لو وصلت الرسالة يبقى كل حاجة شغالة تمام!	2026-02-09 03:55:32.067791
34a4b2f7-cec8-4c19-9dc9-7fb4f87b24f5	احمد	komanda.hamada@gmail.com	برنامج رائع	2026-02-09 03:56:27.730317
aa65ee74-3f52-4505-9daa-21d5a0d40c15	Ahmed hafez	komanda.hamada@gmail.com	Magnificent	2026-02-09 03:58:45.229124
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scans (id, image_url, extracted_text, created_at) FROM stdin;
a07d369e-6f56-4a40-bac4-ce619d7d348e	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4QN2RXhpZgAASUkqAAgAAAALAAABAwABAAAAMAwAAAEBAwABAAAAQBAAAA8BAgAFAAAAogAAABABAgAJAAAAqAAAABIBAwABAAAAAQAAABoBBQABAAAAkgAAABsBBQABAAAAmgAAACgBAwABAAAAA	MISR INSURANCE  \nمصر للتأمين\n\nClaim Form  \nنموذج مطالبات التأمين  \nP442017 رقم المسلسل\n\nرقم البطاقة: 88061297  \nService Date: 08/02/2026  \nSpeciality: gyn&aobs\n\nBorg El Zahra Hospital / Borg El Zahra Hospital - Bani Suef  \nاسم مقدم الخدمة:  \nاسم المريض: مها محمد عبد السميع (العاملين جامعة بني سويف)  \nتاريخ الميلاد: 28/03/1982  \nاسم الشركة: صندوق تحسين أحوال العاملين بالجامعات الحكومية / العاملين جامعة بني سويف\n\nDUB.  \nكشف جديد\n\nPrescribed Medications  \nالأدوية الموصوفة  \nLentron [?]  \n[illegible]  \nsaniblood [?]  \n[illegible]\n\nRequested Medical Procedure  \nالإجراءات المطلوبة  \nCBC  \nPT, PTT, INR  \nSGOT, SGPT  \nS. urea, S. creat  \nEcho, ECG\n\nصلاحية هذا النموذج 15 يوم من تاريخ الكشف\n\ncertifications: I hereby certify that all the information mentioned are correctd & the attached Medical services indicated necessary for the management of this case.\n\nاني افوض شركة .... للخدمات الطبية في الاطلاع والحصول على أي سجلات او ملفات طبية خاصة بي قديمة كانت او حديثة\n\nتوقيع المريض: [signature]\n\n[Stamp]  \n[illegible Arabic stamp text]	2026-02-09 02:40:08.368107
c2a44805-e83e-48d0-a602-94ea6979a8e5	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4QR0RXhpZgAASUkqAAgAAAALAAABAwABAAAAAAwAAAEBAwABAAAAABAAAA8BAgAFAAAAogAAABABAgARAAAAqAAAABIBAwABAAAAAQAAABoBBQABAAAAkgAAABsBBQABAAAAmgAAACgBAwABAAAAA	[No readable text detected in the provided image.]	2026-02-09 02:42:10.261641
a012955b-f4dd-4f49-85fd-911589f9cb6d	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKcBBgYGBgcGBwgIBwoLCgsKDw4MDA4PFhAREBEQFiIVGRUVGRUiHiQeHB4kH	(نموذج رقم ١٣٩ ق. ت)\n\nالهيئة العامة للتأمين الصحي  \nفرع: .................  \nمنطقة: .................  \nعيادة: .................\n\nخطاب تحويل إلى مستشفى\n\nاسم المنتفع: للسيد/ عبد الباسط [؟]        بطاقة التأمين الصحي: .................  \nجهة العمل: .................  \nعنوانه: .................  \nالتاريخ المرضي: .................  \nالتشخيص: .................  \nالعلاج الذي اتبع: .................  \nملاحظات: .................\n\nHepatic U/S\n\nCBC, ESR, CRP, PFT, Creat  \nAT, IgG, IgM, IgE, IgA  \nIgD, CD3, CD4, CD8  \nCD19, CD2, CD56, PBS, [N?]Asr[?]  \n25 OH Vit D, Ca, Fe, Mg, Ph.  \nALP, specific IgE food, C3, C4  \nspecific IgE inhalation\n\nAnti [t?]G level  \nC1 esterase activity\n\nبرجاء تحديد موعد لعلاجه بالقسم الداخلي بالمستشفى.\n\nالطبيب: .................\nتحريراً في: .................\n\n[ختم] مستشفى أبو كبير المركزي  \nالتأمين الصحي – منطقة أبو كبير غرب شرقية	2026-02-09 02:49:48.259779
a56d600a-8170-4c8f-87cf-b4908227984c	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKcBBgYGBgcGBwgIBwoLCgsKDw4MDA4PFhAREBEQFiIVGRUVGRUiHiQeHB4kH	## بيانات المريض\n- الاسم: آية حمدي سيد  \n- تاريخ الميلاد: 1999-07-01  \n- الرقم القومي: 29907012203289  \n- تاريخ إصدار الخطاب: 04-02-2026  \n- رقم: 2026-2096B00141147925  \n- عدد مرات تكرار الإحالة: 1  \n- المستشفى: مستشفى معهد الخدمة (الهيئة العامة للتأمين الصحي) — عيادة السلام  \n\n## التشخيص\n- Calculus gall bladder (ICD-10: K80.2) — حصوات بالمرارة  \n- Gall bladder polyp (ICD-10: K82.4) — سليلة/زائدة لحمية بالمرارة  \n\n## التحاليل المطلوبة\n- Histopathology — فحص أنسجة لتشخيص التغيرات المرضية بالمجهر  \n\n## ملاحظات\n- مستشفى السلام الخيري (AL-SALAM CHARITY HOSPITAL)\n- نص إنجليزي بخط اليد (كما هو مقروء):\n  - “R/ a case of calculus gall bladder with gall bladder polyp”\n  - “Lapar cholecystectomy was done”\n  - “For histopathology”\n- مذكور بنموذج الإحالة: “تحتاج المريض إلى: … عينة صغيرة”\n- “وترسل لمعامل وزارة الصحة للتحاليل الطبية”\n- “العنوان: شبرا”\n- “الهيئة العامة للتأمين الصحي”\n- “خطاب تحويل إلى مستشفى”\n- “العلاج الذي اتبع: … path [غير واضح]”	2026-02-09 03:09:58.923963
\.


--
-- Name: feedbacks feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_pkey PRIMARY KEY (id);


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict MfOG9QUQG0ZcdMgSIRnd2HyV5hidUhHINEwaCTt2fnZb5aupE6DlB3eEoQN1szd

