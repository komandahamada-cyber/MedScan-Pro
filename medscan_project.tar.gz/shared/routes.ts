import { z } from "zod";
import { insertScanSchema, scans } from "./schema";

export const api = {
  scans: {
    create: {
      method: "POST" as const,
      path: "/api/scans" as const,
      // Input is FormData, handled in implementation. 
      // We define the response schema here.
      responses: {
        200: z.custom<typeof scans.$inferSelect>(),
        400: z.object({ message: z.string() }),
        500: z.object({ message: z.string() }),
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/scans/:id" as const,
      responses: {
        200: z.custom<typeof scans.$inferSelect>(),
        404: z.object({ message: z.string() }),
      },
    },
    list: {
      method: "GET" as const,
      path: "/api/scans" as const,
      responses: {
        200: z.array(z.custom<typeof scans.$inferSelect>()),
      },
    },
  },
};
