import { Link, useLocation } from "wouter";
import { Home, History, ScanLine } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-md border-t border-border/50 py-2 px-6 pb-safe z-50 md:hidden">
      <div className="flex justify-around items-center max-w-md mx-auto">
        <Link href="/" className="flex flex-col items-center gap-1" data-testid="nav-home">
          <div className={cn(
            "p-2 rounded-md transition-all duration-200",
            isActive("/") ? "text-primary" : "text-muted-foreground"
          )}>
            <Home size={22} strokeWidth={isActive("/") ? 2.5 : 2} />
          </div>
          <span className={cn("text-[10px] font-medium", isActive("/") ? "text-primary" : "text-muted-foreground")}>
            الرئيسية
          </span>
        </Link>

        <Link href="/" className="relative -top-5" data-testid="nav-scan">
          <div className="bg-primary text-primary-foreground p-4 rounded-full shadow-lg shadow-primary/40 border-4 border-background transition-transform active:scale-95">
            <ScanLine size={26} strokeWidth={2.5} />
          </div>
        </Link>

        <Link href="/history" className="flex flex-col items-center gap-1" data-testid="nav-history">
          <div className={cn(
            "p-2 rounded-md transition-all duration-200",
            isActive("/history") ? "text-primary" : "text-muted-foreground"
          )}>
            <History size={22} strokeWidth={isActive("/history") ? 2.5 : 2} />
          </div>
          <span className={cn("text-[10px] font-medium", isActive("/history") ? "text-primary" : "text-muted-foreground")}>
            السجل
          </span>
        </Link>
      </div>
    </div>
  );
}
