import { Link } from "wouter";
import { ScanLine, Clock, Sun, Moon } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";

export function Header() {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-40 w-full bg-background/90 backdrop-blur-md border-b border-border/50">
      <div className="container mx-auto px-4 h-14 flex items-center justify-between gap-2">
        <Link href="/" className="flex items-center gap-2" data-testid="link-home">
          <div className="bg-primary p-1.5 rounded-md">
            <ScanLine size={18} className="text-primary-foreground" />
          </div>
          <span className="text-lg font-bold text-foreground">
            Med<span className="text-primary">Scan</span>
          </span>
        </Link>

        <div className="flex items-center gap-1">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-md text-muted-foreground"
            data-testid="button-theme-toggle"
          >
            {theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <Link href="/history" className="p-2 rounded-md text-muted-foreground" data-testid="link-history">
            <Clock size={20} />
          </Link>
        </div>
      </div>
    </header>
  );
}
