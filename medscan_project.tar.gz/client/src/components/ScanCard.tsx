import { Link } from "wouter";
import { Calendar, ChevronLeft, Stethoscope, FlaskConical, Pill } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import type { Scan } from "@shared/schema";

interface ScanCardProps {
  scan: Scan;
  index?: number;
}

function extractSummary(text: string) {
  let diagnosis = "";
  let tests: string[] = [];
  let meds: string[] = [];
  let patientName = "";

  let currentSection = "";
  for (const line of text.split("\n")) {
    const trimmed = line.trim();
    if (trimmed.startsWith("#")) {
      const header = trimmed.replace(/^#+\s*/, "").toLowerCase();
      if (header.includes("تشخيص") || header.includes("diagnosis")) currentSection = "diag";
      else if (header.includes("تحاليل") || header.includes("test") || header.includes("فحوص") || header.includes("إجراء")) currentSection = "tests";
      else if (header.includes("أدوية") || header.includes("علاج") || header.includes("medic")) currentSection = "meds";
      else if (header.includes("مريض") || header.includes("patient")) currentSection = "patient";
      else currentSection = "other";
      continue;
    }
    if (!trimmed || trimmed === "---") continue;

    if (currentSection === "diag" && !diagnosis) {
      diagnosis = trimmed.replace(/\*\*/g, "").replace(/\(ICD-10.*?\)/g, "").trim().substring(0, 50);
    } else if (currentSection === "tests") {
      const name = trimmed.split("—")[0].split("–")[0].replace(/\*\*/g, "").replace(/^[-*]\s*/, "").trim();
      if (name && tests.length < 4) tests.push(name.substring(0, 20));
    } else if (currentSection === "meds") {
      const name = trimmed.split("—")[0].split("–")[0].replace(/\*\*/g, "").replace(/^[-*]\s*/, "").trim();
      if (name && meds.length < 3) meds.push(name.substring(0, 20));
    } else if (currentSection === "patient" && !patientName) {
      const nameMatch = trimmed.match(/(?:الاسم|اسم)[:\s]*(.+)/);
      if (nameMatch) patientName = nameMatch[1].replace(/\*\*/g, "").trim().substring(0, 25);
    }
  }

  const cleanLines = text.split("\n").filter(l => {
    const t = l.trim();
    return t && !t.startsWith("#") && t !== "---" && !t.startsWith("[No ") && !t.startsWith("[no ");
  });
  const firstCleanLine = cleanLines[0]?.replace(/\*\*/g, "").substring(0, 40) || "";

  return { diagnosis, tests, meds, patientName, firstCleanLine };
}

export function ScanCard({ scan, index = 0 }: ScanCardProps) {
  const date = scan.createdAt ? new Date(scan.createdAt) : new Date();
  const summary = scan.extractedText ? extractSummary(scan.extractedText) : null;

  const title = summary?.patientName
    || summary?.diagnosis
    || (summary?.firstCleanLine || "").substring(0, 35)
    || "مستند طبي";

  const hasTests = summary && summary.tests.length > 0;
  const hasMeds = summary && summary.meds.length > 0;
  const hasDiag = summary && summary.diagnosis;
  const isProcessing = !scan.extractedText;

  return (
    <Link href={`/scan/${scan.id}`} className="block" data-testid={`card-scan-${scan.id}`}>
      <div className="bg-card border border-border/60 rounded-md px-3 py-2.5 transition-colors">
        <div className="flex items-center gap-2.5">
          {/* Thumbnail */}
          <div className="relative w-10 h-10 rounded-md overflow-hidden bg-secondary flex-shrink-0">
            {scan.imageUrl && scan.imageUrl.length > 200 ? (
              <img src={scan.imageUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Stethoscope size={16} className="text-muted-foreground/60" />
              </div>
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            {/* Title row */}
            <div className="flex items-center gap-2">
              <p className="text-[13px] font-bold text-foreground truncate flex-1" data-testid="text-card-title">
                {title}
              </p>
              {!isProcessing && (
                <span className="text-[9px] font-medium px-1.5 py-[1px] rounded-sm bg-primary/15 text-primary flex-shrink-0">
                  مكتمل
                </span>
              )}
              {isProcessing && (
                <span className="text-[9px] font-medium px-1.5 py-[1px] rounded-sm bg-muted text-muted-foreground flex-shrink-0">
                  معالجة
                </span>
              )}
            </div>

            {/* Info chips row */}
            <div className="flex items-center gap-1.5 mt-1">
              {hasTests && (
                <span className="text-[9px] text-emerald-400 flex items-center gap-0.5">
                  <FlaskConical size={8} />
                  {summary.tests.length}
                </span>
              )}
              {hasMeds && (
                <span className="text-[9px] text-amber-400 flex items-center gap-0.5">
                  <Pill size={8} />
                  {summary.meds.length}
                </span>
              )}
              {hasDiag && (
                <span className="text-[9px] text-primary/70 flex items-center gap-0.5">
                  <Stethoscope size={8} />
                </span>
              )}
              <span className="text-[9px] text-muted-foreground flex items-center gap-0.5 mr-auto">
                <Calendar size={8} />
                {format(date, "d MMM", { locale: ar })}
              </span>
            </div>

            {/* Tests preview */}
            {hasTests && (
              <p className="text-[10px] text-muted-foreground/70 mt-0.5 truncate">
                {summary.tests.join(" / ")}
              </p>
            )}
          </div>

          <ChevronLeft size={14} className="text-muted-foreground/40 flex-shrink-0" />
        </div>
      </div>
    </Link>
  );
}
