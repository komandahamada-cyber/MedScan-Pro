import { useState, useRef, useEffect, useCallback } from "react";
import { Camera, Loader2, ImagePlus, X, SwitchCamera, Zap, ZapOff, Download, Crop, Check } from "lucide-react";
import { useCreateScan } from "@/hooks/use-scans";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import Cropper from "react-easy-crop";
import type { Area } from "react-easy-crop";

async function getCroppedImg(imageSrc: string, pixelCrop: Area): Promise<string> {
  const image = new Image();
  image.src = imageSrc;
  await new Promise((resolve) => { image.onload = resolve; });

  const canvas = document.createElement("canvas");
  canvas.width = pixelCrop.width;
  canvas.height = pixelCrop.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("No canvas context");

  ctx.drawImage(
    image,
    pixelCrop.x, pixelCrop.y,
    pixelCrop.width, pixelCrop.height,
    0, 0,
    pixelCrop.width, pixelCrop.height
  );

  return canvas.toDataURL("image/jpeg", 0.9);
}

export function FileUpload() {
  const [preview, setPreview] = useState<string | null>(null);
  const [cropImage, setCropImage] = useState<string | null>(null);
  const [cropSource, setCropSource] = useState<"camera" | "file">("camera");
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [torchOn, setTorchOn] = useState(false);
  const [torchSupported, setTorchSupported] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { mutate: createScan, isPending } = useCreateScan();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
    setTorchOn(false);
    setTorchSupported(false);
  }, []);

  const startCamera = useCallback(async () => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      const track = stream.getVideoTracks()[0];
      const capabilities = track.getCapabilities?.();
      if (capabilities && "torch" in capabilities) {
        setTorchSupported(true);
      } else {
        setTorchSupported(false);
      }

      setCameraActive(true);
    } catch (err: any) {
      console.error("Camera error:", err);
      toast({
        title: "خطأ في الكاميرا",
        description: "لا يمكن الوصول للكاميرا. تأكد من السماح بالوصول.",
        variant: "destructive",
      });
    }
  }, [facingMode, toast]);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  useEffect(() => {
    if (cameraActive) {
      startCamera();
    }
  }, [facingMode]);

  const toggleTorch = useCallback(async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    try {
      await track.applyConstraints({
        advanced: [{ torch: !torchOn } as any],
      });
      setTorchOn(!torchOn);
    } catch (err) {
      console.error("Torch error:", err);
    }
  }, [torchOn]);

  const capturePhoto = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.9);

    stopCamera();
    setCropImage(dataUrl);
    setCropSource("camera");
    setCrop({ x: 0, y: 0 });
    setZoom(1);
  }, [stopCamera]);

  const onCropComplete = useCallback((_: Area, croppedPixels: Area) => {
    setCroppedAreaPixels(croppedPixels);
  }, []);

  const handleCropConfirm = async () => {
    if (!cropImage || !croppedAreaPixels) return;
    try {
      const croppedDataUrl = await getCroppedImg(cropImage, croppedAreaPixels);
      setCropImage(null);
      setPreview(croppedDataUrl);
      processImage(croppedDataUrl);
    } catch {
      toast({ title: "خطأ", description: "فشل في قص الصورة", variant: "destructive" });
    }
  };

  const handleCropSkip = () => {
    if (!cropImage) return;
    setCropImage(null);
    setPreview(cropImage);
    processImage(cropImage);
  };

  const handleCropCancel = () => {
    setCropImage(null);
    if (cropSource === "camera") {
      startCamera();
    }
  };

  const processImage = (imageData: string) => {
    const formData = new FormData();

    const byteString = atob(imageData.split(",")[1]);
    const mimeString = imageData.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: mimeString });
    formData.append("image", new File([blob], "capture.jpg", { type: mimeString }));

    createScan(formData, {
      onSuccess: (data) => {
        toast({
          title: "تم بنجاح",
          description: "تم تحليل المستند الطبي",
        });
        setLocation(`/scan/${data.id}`);
      },
      onError: () => {
        toast({
          title: "فشل التحليل",
          description: "حدث خطأ أثناء تحليل الصورة، حاول مرة أخرى",
          variant: "destructive",
        });
        setPreview(null);
        startCamera();
      }
    });
  };

  const handleFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast({
        title: "خطأ في الملف",
        description: "يرجى تحميل ملف صورة صالح (JPG, PNG)",
        variant: "destructive",
      });
      return;
    }

    stopCamera();

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setCropImage(dataUrl);
      setCropSource("file");
      setCrop({ x: 0, y: 0 });
      setZoom(1);
    };
    reader.readAsDataURL(file);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  return (
    <div className="w-full flex flex-col items-center gap-6" data-testid="file-upload-container">
      {/* Cropping UI */}
      {cropImage && !isPending && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col" data-testid="crop-overlay">
          <div className="flex items-center justify-between px-4 py-3 bg-black/80 z-10">
            <button onClick={handleCropCancel} className="text-white text-sm font-medium p-2" data-testid="button-crop-cancel">
              <X size={20} />
            </button>
            <span className="text-white text-sm font-bold flex items-center gap-2">
              <Crop size={16} />
              قص الصورة
            </span>
            <button onClick={handleCropSkip} className="text-muted-foreground text-xs font-medium p-2" data-testid="button-crop-skip">
              تخطي
            </button>
          </div>
          <div className="flex-1 relative">
            <Cropper
              image={cropImage}
              crop={crop}
              zoom={zoom}
              aspect={undefined}
              onCropChange={setCrop}
              onZoomChange={setZoom}
              onCropComplete={onCropComplete}
            />
          </div>
          <div className="flex items-center justify-center gap-4 px-4 py-4 bg-black/80">
            <input
              type="range"
              min={1}
              max={3}
              step={0.1}
              value={zoom}
              onChange={(e) => setZoom(Number(e.target.value))}
              className="w-40 accent-primary"
              data-testid="input-crop-zoom"
            />
            <button
              onClick={handleCropConfirm}
              className="bg-primary text-primary-foreground font-bold px-6 py-2.5 rounded-md text-sm flex items-center gap-2"
              data-testid="button-crop-confirm"
            >
              <Check size={16} />
              تأكيد
            </button>
          </div>
        </div>
      )}

      {/* Viewfinder Area */}
      <div className="relative w-full max-w-sm aspect-[3/4] mx-auto">
        {/* Corner Brackets */}
        <div className="absolute top-0 left-0 w-10 h-10 border-t-2 border-l-2 border-primary rounded-tl-md pulse-border z-10" />
        <div className="absolute top-0 right-0 w-10 h-10 border-t-2 border-r-2 border-primary rounded-tr-md pulse-border z-10" />
        <div className="absolute bottom-0 left-0 w-10 h-10 border-b-2 border-l-2 border-primary rounded-bl-md pulse-border z-10" />
        <div className="absolute bottom-0 right-0 w-10 h-10 border-b-2 border-r-2 border-primary rounded-br-md pulse-border z-10" />

        {/* Inner content */}
        <div className="absolute inset-3 rounded-md overflow-hidden bg-black flex items-center justify-center">
          {isPending ? (
            <div className="flex flex-col items-center gap-4 relative w-full h-full">
              {preview && (
                <img src={preview} alt="preview" className="w-full h-full absolute inset-0 object-cover opacity-40" />
              )}
              <div className="relative z-10 flex flex-col items-center gap-4 justify-center h-full">
                <Loader2 className="w-14 h-14 text-primary animate-spin" />
                <p className="text-white font-bold text-lg">جاري التحليل...</p>
                <p className="text-white/60 text-sm">يقرأ الذكاء الاصطناعي المستند</p>
              </div>
              <div className="absolute inset-0 pointer-events-none">
                <div className="scan-line absolute left-0 right-0 h-0.5 bg-gradient-to-l from-transparent via-primary to-transparent" />
              </div>
            </div>
          ) : cameraActive ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
              data-testid="video-camera"
            />
          ) : preview ? (
            <img src={preview} alt="preview" className="w-full h-full object-cover" />
          ) : (
            <div className="flex flex-col items-center gap-3 text-muted-foreground">
              <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center">
                <Camera size={32} className="text-muted-foreground/70" />
              </div>
              <p className="text-sm font-medium">ضع المستند الطبي هنا</p>
            </div>
          )}

          {/* Camera overlay controls */}
          {cameraActive && !isPending && (
            <div className="absolute top-2 left-2 right-2 flex items-center justify-between gap-2 z-20">
              <button
                onClick={() => setFacingMode(f => f === "environment" ? "user" : "environment")}
                className="w-9 h-9 rounded-full bg-black/50 flex items-center justify-center text-white"
                data-testid="button-switch-camera"
              >
                <SwitchCamera size={18} />
              </button>
              {torchSupported && (
                <button
                  onClick={toggleTorch}
                  className="w-9 h-9 rounded-full bg-black/50 flex items-center justify-center text-white"
                  data-testid="button-torch"
                >
                  {torchOn ? <Zap size={18} className="text-yellow-400" /> : <ZapOff size={18} />}
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="flex items-center justify-center gap-8 w-full max-w-xs mx-auto" data-testid="upload-controls">
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={isPending}
          className="w-14 h-14 rounded-full bg-secondary border border-border flex items-center justify-center text-muted-foreground transition-colors disabled:opacity-50"
          data-testid="button-gallery"
        >
          <ImagePlus size={22} />
        </button>

        {cameraActive ? (
          <button
            onClick={capturePhoto}
            disabled={isPending}
            className="w-[72px] h-[72px] rounded-full bg-primary flex items-center justify-center shadow-lg shadow-primary/40 border-4 border-primary/30 transition-transform active:scale-95 disabled:opacity-50"
            data-testid="button-capture"
          >
            <div className="w-[56px] h-[56px] rounded-full bg-white border-2 border-primary-foreground/30" />
          </button>
        ) : (
          <button
            onClick={startCamera}
            disabled={isPending}
            className="w-[72px] h-[72px] rounded-full bg-primary flex items-center justify-center shadow-lg shadow-primary/40 border-4 border-primary/30 transition-transform active:scale-95 disabled:opacity-50"
            data-testid="button-camera"
          >
            <div className="w-[56px] h-[56px] rounded-full bg-primary border-2 border-primary-foreground/30 flex items-center justify-center">
              <Camera size={24} className="text-primary-foreground" />
            </div>
          </button>
        )}

        {cameraActive ? (
          <button
            onClick={stopCamera}
            disabled={isPending}
            className="w-14 h-14 rounded-full bg-secondary border border-border flex items-center justify-center text-muted-foreground transition-colors disabled:opacity-50"
            data-testid="button-close-camera"
          >
            <X size={22} />
          </button>
        ) : (
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isPending}
            className="w-14 h-14 rounded-full bg-secondary border border-border flex items-center justify-center text-muted-foreground transition-colors disabled:opacity-50"
            data-testid="button-file"
          >
            <Download size={22} />
          </button>
        )}
      </div>

      <canvas ref={canvasRef} className="hidden" />

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleChange}
        data-testid="input-file"
      />
    </div>
  );
}
