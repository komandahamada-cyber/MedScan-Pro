import { useScans } from "@/hooks/use-scans";
import { ScanCard } from "@/components/ScanCard";
import { Loader2, Search } from "lucide-react";
import { useState } from "react";

export default function History() {
  const { data: scans, isLoading, isError } = useScans();
  const [searchTerm, setSearchTerm] = useState("");

  const filteredScans = scans?.filter(scan =>
    scan.extractedText?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    scan.id.includes(searchTerm)
  );

  return (
    <div className="container mx-auto max-w-2xl px-4 py-6 pb-24">
      <h1 className="text-2xl font-bold mb-4" data-testid="text-history-title">سجل المستندات</h1>

      <div className="relative mb-6">
        <div className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          <Search size={18} />
        </div>
        <input
          type="text"
          placeholder="ابحث في المستندات..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-secondary border border-border rounded-md py-2.5 pr-10 pl-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all"
          data-testid="input-search"
        />
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-16">
          <Loader2 className="w-8 h-8 animate-spin text-primary mb-3" />
          <p className="text-muted-foreground text-sm">جاري التحميل...</p>
        </div>
      ) : isError ? (
        <div className="text-center py-12 text-destructive text-sm" data-testid="text-error">
          حدث خطأ في تحميل البيانات
        </div>
      ) : !filteredScans || filteredScans.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground text-sm" data-testid="text-empty">
          {searchTerm ? "لا توجد نتائج مطابقة" : "لا توجد مستندات محفوظة"}
        </div>
      ) : (
        <div className="space-y-3">
          {filteredScans.map((scan, index) => (
            <ScanCard key={scan.id} scan={scan} index={index} />
          ))}
        </div>
      )}
    </div>
  );
}
