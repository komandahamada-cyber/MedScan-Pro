import { useScans } from "@/hooks/use-scans";
import { FileUpload } from "@/components/FileUpload";
import { ScanCard } from "@/components/ScanCard";
import { Loader2, FileText, MessageSquarePlus, Send, X, BarChart3, FlaskConical, Pill, Stethoscope } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { Link } from "wouter";
import { useState, useMemo } from "react";
import { useToast } from "@/hooks/use-toast";

function ScanStats({ scans }: { scans: any[] }) {
  const stats = useMemo(() => {
    let totalScans = scans.length;
    let completedScans = 0;
    let totalTests = 0;
    let totalMeds = 0;
    let totalDiagnoses = 0;

    for (const scan of scans) {
      if (scan.extractedText) {
        completedScans++;
        const text = scan.extractedText;
        let currentSection = "";
        for (const line of text.split("\n")) {
          const trimmed = line.trim();
          if (trimmed.startsWith("#")) {
            const header = trimmed.replace(/^#+\s*/, "").toLowerCase();
            if (header.includes("تحاليل") || header.includes("test") || header.includes("فحوص")) currentSection = "tests";
            else if (header.includes("أدوية") || header.includes("علاج") || header.includes("medic")) currentSection = "meds";
            else if (header.includes("تشخيص") || header.includes("diagnosis")) currentSection = "diag";
            else currentSection = "other";
            continue;
          }
          if (!trimmed || trimmed === "---") continue;
          if (currentSection === "tests") totalTests++;
          else if (currentSection === "meds") totalMeds++;
          else if (currentSection === "diag") totalDiagnoses++;
        }
      }
    }

    return { totalScans, completedScans, totalTests, totalMeds, totalDiagnoses };
  }, [scans]);

  if (stats.totalScans === 0) return null;

  return (
    <div className="grid grid-cols-4 gap-2 max-w-2xl mx-auto w-full" data-testid="scan-stats">
      <div className="bg-card border border-border/60 rounded-md p-2.5 text-center">
        <BarChart3 size={14} className="text-primary mx-auto mb-1" />
        <p className="text-lg font-bold text-foreground" data-testid="stat-total">{stats.totalScans}</p>
        <p className="text-[9px] text-muted-foreground">مستند</p>
      </div>
      <div className="bg-card border border-border/60 rounded-md p-2.5 text-center">
        <Stethoscope size={14} className="text-primary mx-auto mb-1" />
        <p className="text-lg font-bold text-foreground" data-testid="stat-diagnoses">{stats.totalDiagnoses}</p>
        <p className="text-[9px] text-muted-foreground">تشخيص</p>
      </div>
      <div className="bg-card border border-border/60 rounded-md p-2.5 text-center">
        <FlaskConical size={14} className="text-emerald-400 mx-auto mb-1" />
        <p className="text-lg font-bold text-foreground" data-testid="stat-tests">{stats.totalTests}</p>
        <p className="text-[9px] text-muted-foreground">تحليل</p>
      </div>
      <div className="bg-card border border-border/60 rounded-md p-2.5 text-center">
        <Pill size={14} className="text-amber-400 mx-auto mb-1" />
        <p className="text-lg font-bold text-foreground" data-testid="stat-meds">{stats.totalMeds}</p>
        <p className="text-[9px] text-muted-foreground">دواء</p>
      </div>
    </div>
  );
}

function FeedbackDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const { toast } = useToast();

  if (!open) return null;

  const handleSend = async () => {
    if (!message.trim()) {
      toast({ title: "اكتب رسالتك", description: "يرجى كتابة رسالة قبل الإرسال", variant: "destructive" });
      return;
    }

    setSending(true);
    try {
      const res = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim() || null, email: email.trim() || null, message: message.trim() }),
      });
      if (!res.ok) throw new Error();
      toast({ title: "تم الإرسال", description: "شكراً لملاحظاتك! سنتواصل معك قريباً" });
      setName("");
      setEmail("");
      setMessage("");
      onClose();
    } catch {
      toast({ title: "خطأ", description: "حدث خطأ أثناء الإرسال، حاول مرة أخرى", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center sm:items-center" data-testid="feedback-dialog">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card border border-border rounded-t-xl sm:rounded-xl w-full max-w-md p-5 space-y-4 z-10 animate-in slide-in-from-bottom-4">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-base font-bold text-foreground flex items-center gap-2">
            <MessageSquarePlus size={18} className="text-amber-400" />
            Feedback
          </h2>
          <button onClick={onClose} className="p-1.5 rounded-md text-muted-foreground" data-testid="button-close-feedback">
            <X size={18} />
          </button>
        </div>

        <p className="text-xs text-muted-foreground">
          شاركنا رأيك أو أي مشكلة واجهتك وسنعمل على تحسين التطبيق
        </p>

        <div className="space-y-3">
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="اسمك (اختياري)"
            className="w-full bg-secondary border border-border/60 rounded-md px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-amber-400/50"
            data-testid="input-feedback-name"
          />
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="بريدك الإلكتروني (اختياري)"
            className="w-full bg-secondary border border-border/60 rounded-md px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-amber-400/50"
            data-testid="input-feedback-email"
          />
          <textarea
            value={message}
            onChange={e => setMessage(e.target.value)}
            placeholder="اكتب رسالتك هنا..."
            rows={4}
            className="w-full bg-secondary border border-border/60 rounded-md px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-amber-400/50 resize-none"
            data-testid="input-feedback-message"
          />
        </div>

        <button
          onClick={handleSend}
          disabled={sending}
          className="w-full flex items-center justify-center gap-2 bg-amber-500 text-black font-bold py-2.5 rounded-md text-sm transition-opacity disabled:opacity-50"
          data-testid="button-send-feedback"
        >
          <Send size={14} />
          إرسال
        </button>
      </div>
    </div>
  );
}

export default function Home() {
  const { data: scans, isLoading } = useScans();
  const [feedbackOpen, setFeedbackOpen] = useState(false);

  const recentScans = scans?.slice(0, 3);

  return (
    <div className="flex flex-col gap-6 pb-24 pt-4 px-4">
      {/* Scanner Area */}
      <section>
        <FileUpload />
      </section>

      {/* Scan Statistics */}
      {scans && scans.length > 0 && <ScanStats scans={scans} />}

      {/* Developer Info */}
      <div className="flex flex-col items-center gap-1 text-center" data-testid="developer-info">
        <p className="text-sm font-bold text-foreground">AHMED ASHRAF</p>
        <a
          href="https://wa.me/201098811992"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-green-500"
          data-testid="link-whatsapp"
        >
          <SiWhatsapp size={14} />
          <span>واتساب المطور</span>
        </a>
      </div>

      {/* Feedback Button */}
      <button
        onClick={() => setFeedbackOpen(true)}
        className="mx-auto flex items-center gap-2 bg-amber-500/15 border border-amber-500/30 text-amber-400 font-bold px-5 py-2.5 rounded-md text-sm transition-colors"
        data-testid="button-feedback"
      >
        <MessageSquarePlus size={16} />
        Feedback
      </button>

      {/* Recent Scans */}
      {recentScans && recentScans.length > 0 && (
        <section className="max-w-2xl mx-auto w-full">
          <div className="flex items-center justify-between gap-2 mb-4">
            <h2 className="text-base font-bold text-foreground">
              آخر المستندات
            </h2>
            <Link href="/history" className="text-xs text-primary font-medium" data-testid="link-view-all">
              عرض الكل
            </Link>
          </div>

          <div className="space-y-3">
            {recentScans.map((scan, index) => (
              <ScanCard key={scan.id} scan={scan} index={index} />
            ))}
          </div>
        </section>
      )}

      {isLoading && (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      )}

      {!isLoading && (!scans || scans.length === 0) && (
        <div className="text-center py-8 text-muted-foreground">
          <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-3">
            <FileText size={24} className="text-muted-foreground/50" />
          </div>
          <p className="text-sm">لا توجد مستندات بعد</p>
          <p className="text-xs mt-1">التقط صورة لمستند طبي للبدء</p>
        </div>
      )}

      <FeedbackDialog open={feedbackOpen} onClose={() => setFeedbackOpen(false)} />
    </div>
  );
}
