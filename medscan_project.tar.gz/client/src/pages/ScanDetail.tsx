import { useParams, Link, useLocation } from "wouter";
import { useScan, useDeleteScan } from "@/hooks/use-scans";
import { Loader2, ArrowLeft, Copy, Check, QrCode, User, Stethoscope, FlaskConical, Pill, StickyNote, ChevronDown, Trash2, Share2, Download, ZoomIn, X } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import QRCode from "react-qr-code";
import { useState, useRef, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

interface ParsedSection {
  title: string;
  icon: typeof User;
  content: string[];
  color: string;
}

function parseExtractedText(text: string): ParsedSection[] {
  const sections: ParsedSection[] = [];

  const sectionDefs: { keywords: string[]; icon: typeof User; color: string; label: string }[] = [
    { keywords: ["بيانات المريض", "معلومات المريض", "patient"], icon: User, color: "text-blue-400", label: "بيانات المريض" },
    { keywords: ["التشخيص", "diagnosis", "تشخيص", "ICD"], icon: Stethoscope, color: "text-primary", label: "التشخيص" },
    { keywords: ["التحاليل", "تحاليل", "tests", "lab", "فحوصات", "إجراءات"], icon: FlaskConical, color: "text-emerald-400", label: "التحاليل المطلوبة" },
    { keywords: ["الأدوية", "أدوية", "علاج", "medications", "drugs", "prescri"], icon: Pill, color: "text-amber-400", label: "الأدوية" },
    { keywords: ["ملاحظات", "notes", "أخرى", "other"], icon: StickyNote, color: "text-muted-foreground", label: "ملاحظات" },
  ];

  const findDef = (title: string) => {
    const lower = title.toLowerCase();
    return sectionDefs.find(d => d.keywords.some(k => lower.includes(k.toLowerCase())));
  };

  const headerRegex = /^#{1,3}\s*(.+)$/gm;
  const parts = text.split(headerRegex);

  if (parts.length <= 1) {
    const lines = text.split("\n").filter(l => l.trim() && l.trim() !== "---" && !l.trim().startsWith("**"));
    if (lines.length > 0) {
      sections.push({
        title: "النتائج",
        icon: Stethoscope,
        content: lines,
        color: "text-foreground",
      });
    }
    return sections;
  }

  for (let i = 1; i < parts.length; i += 2) {
    const title = parts[i]?.trim();
    const body = parts[i + 1]?.trim();
    if (!title || !body) continue;

    const lines = body.split("\n").filter(l => {
      const t = l.trim();
      return t && t !== "---" && t !== "—" && t !== "-";
    });
    if (lines.length === 0) continue;

    const def = findDef(title);

    sections.push({
      title: def?.label || title,
      icon: def?.icon || StickyNote,
      content: lines,
      color: def?.color || "text-foreground",
    });
  }

  return sections;
}

function CollapsibleSection({ section, defaultOpen }: { section: ParsedSection; defaultOpen: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  const Icon = section.icon;

  return (
    <div className="border border-border/50 rounded-md overflow-visible" data-testid={`section-${section.title}`}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-3 py-2.5 text-right"
        data-testid={`button-toggle-${section.title}`}
      >
        <Icon size={16} className={section.color} />
        <span className="flex-1 text-sm font-bold text-foreground">{section.title}</span>
        <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded-sm">{section.content.length}</span>
        <ChevronDown size={14} className={`text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="px-3 pb-3 space-y-1.5 border-t border-border/30 pt-2">
          {section.content.map((line, i) => (
            <p key={i} className="text-sm text-foreground/90 leading-relaxed">{line}</p>
          ))}
        </div>
      )}
    </div>
  );
}

function ImageZoomModal({ src, onClose }: { src: string; onClose: () => void }) {
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const lastPos = useRef({ x: 0, y: 0 });

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    setScale(s => Math.max(0.5, Math.min(5, s - e.deltaY * 0.002)));
  }, []);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setDragging(true);
      lastPos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (dragging && e.touches.length === 1) {
      const dx = e.touches[0].clientX - lastPos.current.x;
      const dy = e.touches[0].clientY - lastPos.current.y;
      lastPos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      setPosition(p => ({ x: p.x + dx, y: p.y + dy }));
    }
  }, [dragging]);

  return (
    <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center" data-testid="image-zoom-modal">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white"
        data-testid="button-close-zoom"
      >
        <X size={20} />
      </button>
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-3 z-10">
        <button onClick={() => setScale(s => Math.max(0.5, s - 0.5))} className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white text-lg font-bold" data-testid="button-zoom-out">-</button>
        <span className="text-white text-sm min-w-[3rem] text-center">{Math.round(scale * 100)}%</span>
        <button onClick={() => setScale(s => Math.min(5, s + 0.5))} className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white text-lg font-bold" data-testid="button-zoom-in">+</button>
      </div>
      <div
        className="w-full h-full overflow-hidden touch-none"
        onWheel={handleWheel}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={() => setDragging(false)}
      >
        <img
          src={src}
          alt="zoom"
          className="max-w-none"
          style={{
            transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
            transformOrigin: "center center",
            width: "100%",
            height: "100%",
            objectFit: "contain",
          }}
          draggable={false}
        />
      </div>
    </div>
  );
}

export default function ScanDetail() {
  const { id } = useParams();
  const { data: scan, isLoading, isError } = useScan(id || "");
  const { mutate: deleteScan, isPending: isDeleting } = useDeleteScan();
  const [activeTab, setActiveTab] = useState<'text' | 'qr'>('text');
  const [copied, setCopied] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showZoom, setShowZoom] = useState(false);
  const [exporting, setExporting] = useState(false);
  const resultsRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleCopy = () => {
    if (scan?.extractedText) {
      navigator.clipboard.writeText(scan.extractedText);
      setCopied(true);
      toast({ title: "تم النسخ", description: "تم نسخ النص إلى الحافظة" });
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDelete = () => {
    if (!id) return;
    deleteScan(id, {
      onSuccess: () => {
        toast({ title: "تم الحذف", description: "تم حذف المستند بنجاح" });
        setLocation("/");
      },
      onError: () => {
        toast({ title: "خطأ", description: "فشل في حذف المستند", variant: "destructive" });
      },
    });
    setShowDeleteConfirm(false);
  };

  const handleWhatsAppShare = () => {
    if (!scan?.extractedText) return;
    const text = encodeURIComponent(scan.extractedText.substring(0, 2000));
    window.open(`https://wa.me/?text=${text}`, "_blank");
  };

  const handleExportImage = async () => {
    if (!resultsRef.current) return;
    setExporting(true);
    try {
      const html2canvas = (await import("html2canvas")).default;
      const canvas = await html2canvas(resultsRef.current, {
        backgroundColor: "#1a1a1a",
        scale: 2,
        useCORS: true,
      });
      const link = document.createElement("a");
      link.download = `medscan-${id?.substring(0, 8)}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
      toast({ title: "تم التصدير", description: "تم حفظ النتائج كصورة" });
    } catch {
      toast({ title: "خطأ", description: "فشل في تصدير الصورة", variant: "destructive" });
    } finally {
      setExporting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
        <h2 className="mt-6 text-lg font-bold" data-testid="text-loading">جاري التحميل...</h2>
      </div>
    );
  }

  if (isError || !scan) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center">
        <h2 className="text-lg font-bold text-destructive mb-2" data-testid="text-error">لم يتم العثور على المستند</h2>
        <Link href="/" className="text-primary text-sm font-medium" data-testid="link-back-home">
          العودة للرئيسية
        </Link>
      </div>
    );
  }

  const scanDate = scan.createdAt ? new Date(scan.createdAt) : new Date();
  const parsedSections = scan.extractedText ? parseExtractedText(scan.extractedText) : [];
  const hasImage = scan.imageUrl && scan.imageUrl.length > 200;

  return (
    <div className="min-h-screen pb-24">
      {/* Top bar */}
      <div className="sticky top-0 z-30 bg-background/90 backdrop-blur-md border-b border-border/50 px-4 py-3 flex items-center justify-between gap-2">
        <Link href="/" className="p-2 rounded-md text-muted-foreground" data-testid="button-back">
          <ArrowLeft size={20} />
        </Link>
        <h1 className="text-base font-bold flex-1 text-center" data-testid="text-scan-title">نتيجة الفحص</h1>
        <div className="flex items-center gap-1">
          <button onClick={handleCopy} className="p-2 rounded-md text-muted-foreground" data-testid="button-copy">
            {copied ? <Check size={18} className="text-primary" /> : <Copy size={18} />}
          </button>
          <button onClick={() => setShowDeleteConfirm(true)} className="p-2 rounded-md text-muted-foreground" data-testid="button-delete">
            <Trash2 size={18} />
          </button>
        </div>
      </div>

      {/* Date + image zoom */}
      <div className="px-4 py-2 flex items-center justify-between gap-2">
        <span className="text-xs text-muted-foreground" data-testid="text-scan-date">
          {format(scanDate, "EEEE, d MMMM yyyy - HH:mm", { locale: ar })}
        </span>
        {hasImage && (
          <button onClick={() => setShowZoom(true)} className="text-xs text-primary flex items-center gap-1" data-testid="button-zoom-image">
            <ZoomIn size={14} />
            عرض الصورة
          </button>
        )}
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-2 px-4 pb-3">
        <button
          onClick={handleWhatsAppShare}
          className="flex-1 flex items-center justify-center gap-2 bg-green-600/15 border border-green-600/30 text-green-500 font-medium py-2 rounded-md text-xs"
          data-testid="button-share-whatsapp"
        >
          <SiWhatsapp size={14} />
          واتساب
        </button>
        <button
          onClick={handleExportImage}
          disabled={exporting}
          className="flex-1 flex items-center justify-center gap-2 bg-blue-600/15 border border-blue-600/30 text-blue-400 font-medium py-2 rounded-md text-xs disabled:opacity-50"
          data-testid="button-export-image"
        >
          {exporting ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
          حفظ كصورة
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border/50 mx-4">
        <button
          onClick={() => setActiveTab('text')}
          className={`flex-1 py-2.5 text-sm font-medium transition-colors relative ${
            activeTab === 'text' ? 'text-primary' : 'text-muted-foreground'
          }`}
          data-testid="tab-text"
        >
          النتائج
          {activeTab === 'text' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('qr')}
          className={`flex-1 py-2.5 text-sm font-medium transition-colors relative ${
            activeTab === 'qr' ? 'text-primary' : 'text-muted-foreground'
          }`}
          data-testid="tab-qr"
        >
          رمز QR
          {activeTab === 'qr' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
          )}
        </button>
      </div>

      {/* Tab Content */}
      <div className="p-4">
        {activeTab === 'text' ? (
          <div className="space-y-2" ref={resultsRef}>
            {parsedSections.length > 0 ? (
              parsedSections.map((section, i) => (
                <CollapsibleSection key={i} section={section} defaultOpen={i < 3} />
              ))
            ) : scan.extractedText ? (
              <div className="bg-secondary/50 p-4 rounded-md border border-border/50 text-foreground leading-loose text-sm whitespace-pre-wrap" data-testid="text-extracted">
                {scan.extractedText}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground text-center">
                <Loader2 className="w-6 h-6 animate-spin mb-3 text-primary" />
                <p className="text-sm">لم يتم استخراج النص بعد...</p>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 gap-6">
            <div className="bg-white p-4 rounded-md">
              {scan.extractedText ? (
                <QRCode
                  value={scan.extractedText.substring(0, 2900)}
                  size={200}
                  style={{ height: "auto", maxWidth: "100%", width: "100%" }}
                  data-testid="qr-code"
                />
              ) : (
                <div className="w-[200px] h-[200px] bg-secondary flex items-center justify-center rounded-md">
                  <Loader2 className="animate-spin text-muted-foreground" />
                </div>
              )}
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-bold text-sm flex items-center justify-center gap-2" data-testid="text-share-label">
                <QrCode className="text-primary" size={16} />
                شارك النتائج
              </h3>
              <p className="text-xs text-muted-foreground max-w-xs">
                امسح الرمز لمشاركة النتائج مع الطبيب أو الصيدلية
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Delete confirmation */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center" data-testid="delete-confirm-dialog">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowDeleteConfirm(false)} />
          <div className="relative bg-card border border-border rounded-md w-[90%] max-w-sm p-5 z-10 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-destructive/15 flex items-center justify-center mx-auto">
              <Trash2 size={22} className="text-destructive" />
            </div>
            <h3 className="font-bold text-foreground">حذف المستند؟</h3>
            <p className="text-sm text-muted-foreground">لا يمكن التراجع عن هذا الإجراء</p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 py-2.5 rounded-md border border-border text-sm font-medium text-foreground"
                data-testid="button-cancel-delete"
              >
                إلغاء
              </button>
              <button
                onClick={handleDelete}
                disabled={isDeleting}
                className="flex-1 py-2.5 rounded-md bg-destructive text-destructive-foreground text-sm font-bold disabled:opacity-50"
                data-testid="button-confirm-delete"
              >
                {isDeleting ? <Loader2 size={16} className="animate-spin mx-auto" /> : "حذف"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image zoom modal */}
      {showZoom && hasImage && (
        <ImageZoomModal src={scan.imageUrl} onClose={() => setShowZoom(false)} />
      )}
    </div>
  );
}
