## Packages
react-qr-code | Generating QR codes from extracted text
framer-motion | Smooth animations for page transitions and UI elements
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes

## Notes
The application requires RTL (Right-to-Left) layout for Arabic support.
Ensure the font family supports Arabic characters well (e.g., Cairo or Tajawal).
